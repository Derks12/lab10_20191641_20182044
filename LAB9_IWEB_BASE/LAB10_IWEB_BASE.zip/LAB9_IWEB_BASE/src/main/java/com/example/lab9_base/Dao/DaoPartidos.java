package com.example.lab9_base.Dao;

import com.example.lab9_base.Bean.Partido;

import java.util.ArrayList;

public class DaoPartidos {
    public ArrayList<Partido> listaDePartidos() {

        ArrayList<Partido> partidos = new ArrayList<>();
        /*
        Inserte su código aquí
        */
        return partidos;
    }

    public void crearPartido(Partido partido) {

        /*
        Inserte su código aquí
        */
    }
}
