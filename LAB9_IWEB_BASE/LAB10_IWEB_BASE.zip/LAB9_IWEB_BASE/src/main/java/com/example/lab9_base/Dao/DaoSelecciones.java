package com.example.lab9_base.Dao;

import com.example.lab9_base.Bean.Seleccion;

import java.util.ArrayList;

public class DaoSelecciones {
    public ArrayList<Seleccion> listarSelecciones() {

        ArrayList<Seleccion> selecciones = new ArrayList<>();
        /*
        Inserte su código aquí
        */
        return selecciones;
    }

}
